
console.log('ChromiumOS Anti-Virus PRO');

// var paused = null;
/*
chrome.runtime.sendMessage("check_status_query", function (response) {
  // document.getElementById("testbtn").innerHTML = response;
  if (response == 'not_paused') {
    paused = false;
    document.getElementById('mainbtn').innerHTML = 'Pause Archiving';
  }
  if (response == 'paused') {
    paused = true;
    document.getElementById('mainbtn').innerHTML = 'Resume Archiving';
  }
});
*/

/*
// see YouTube tutorial on chrome messaging: https://www.youtube.com/watch?v=wjiku6X-hd8
document.getElementById("mainbtn").addEventListener("click", function() {
  if (paused == false) {
    chrome.runtime.sendMessage("pause");
    document.getElementById("mainbtn").innerHTML = 'Resume Archiving';
    paused = true;
  } else {
    chrome.runtime.sendMessage("resume");
    document.getElementById("mainbtn").innerHTML = 'Pause Archiving';
    paused = false;
  }
});
*/
