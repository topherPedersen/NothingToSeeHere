
/*
var waybackTabId = null;
var pause = false;

var tabProperties = {
  active: false, 
  url: "https://archive.org/web/",
  index: 0
};

function onTabCreate() {
  // execute this code on tab creation (can be left empty)
  chrome.tabs.query(queryInfo, function(tabs) {

    waybackTabId = tabs[0].id;

  });
}

var queryInfo = {
};

var task = 1;
var archive = new Array();
archive[0] = 'http://placeholder.url';
var lastPageArchived = 0; // this is an index
setInterval(function() {
  chrome.tabs.query(queryInfo, function(tabs) { 

    if (task == 1) { // task one cycles through open tabs, and adds new links to the array of urls to be indexed (archive)

      var hyperlink = new Array();
      for (i = 0; i < tabs.length; i++) {
        var string = '' + tabs[i].url + '';
        var expression = 'archive.org';
        var found = string.match(expression); // regular expression, does this url contain 'archive.org' ?

        var string2 = '' + tabs[i].url + '';
        var expression2 = 'chrome:';
        var found2 = string2.match(expression2);

        var string3 = '' + tabs[i].url + '';
        var expression3 = 'google.com';
        var found3 = string3.match(expression3);

        if (found === null && found2 === null && found3 === null) { // if the url is not an archive.org url, add it to the list of hyperlinks (we don't want to add the archive.org tab that is doing all of the archiving!) ... also excludes new browser tab urls such as chrome:// ... and google search results identified by urls containing 'search?q'
          hyperlink[i] = tabs[i].url;
        }
      }

      for (i = 0; i < hyperlink.length; i++) {
        var uniqueHyperlink = true;
        for (j = 0; j < archive.length; j++) {
          if (hyperlink[i] === archive[j]) {
            uniqueHyperlink = false;
          }
        }
        if (uniqueHyperlink && hyperlink[i] != undefined) {
          archive[archive.length] = hyperlink[i];
        }
      }
    } // end task 1 ------------------------------------------------------------------------>

    if (task == 2) {
      if (pause) {
        return; // if the user has paused the extension, return from setInterval function, do not save page on wayback machine
      }
      if (lastPageArchived < archive.length - 1) { // if there are more pages to be archived, then archive the next one
        if (waybackTabId == null) {
          tabProperties.url = 'https://web.archive.org/save/' + archive[lastPageArchived + 1] + '';
          chrome.tabs.create(tabProperties, onTabCreate);
          lastPageArchived++;
        } else {
          // check to see if tab still exists, or whether we need to create a new one
          chrome.tabs.get(waybackTabId, function(tab) {
            var tabExists;
            if (typeof tab !== 'undefined'){
              tabExists = true;
              var url_str = 'https://web.archive.org/save/' + archive[lastPageArchived + 1] + '';
              chrome.tabs.update(waybackTabId, {url: url_str});
              lastPageArchived++;
            } else {
              tabExists = false;
              tabProperties.url = 'https://web.archive.org/save/' + archive[lastPageArchived + 1] + '';
              chrome.tabs.create(tabProperties, onTabCreate);
              lastPageArchived++;
            }
          });
        }
      }
    } // end task 2

    // setInterval calls this main code block every 15 seconds.
    // everytime the code block is run, we either run task 1, or task 2.
    // after the task is completed, we change the task number so the computer
    // knows which task to run the next time. (task variable will flip back and
    // forth between 1 and 2 every 15 seconds.)
    if (task == 1) {
      task = 2;
    } else {
      task = 1;
    }

  }); // end chrome.tabs.query
}, 15000); // end big setInterval


// see YouTube tutorial on chrome messaging: https://www.youtube.com/watch?v=wjiku6X-hd8
chrome.runtime.onMessage.addListener(function (response, sender, sendResponse) {

  // The Two Following If Statements Tell The UI Whether Archiving Has Been Paused.
  // This is necessary for the ui to determine what text to print on the main ui button.
  if (response == 'check_status_query' && pause == false) {
    sendResponse("not_paused");
  }
  if (response == 'check_status_query' && pause != false) {
    sendResponse("paused");
  }

  // The next two if statements tell background.js whether or not it should pause or resume archiving
  // following a button click from the user interface. Ex: user clicks the 'Pause Archiving' button,
  // and this script, background.js, will pause. If the user clicks the 'Resume Archiving' button,
  // this script will resume archiving.
  if (response == 'pause') {
    pause = true;
  }
  if (response == 'resume') {
    pause = false;
  }
});
*/
