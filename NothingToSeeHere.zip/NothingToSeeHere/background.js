// Devious Chrome Extension by Christine & Topher

var queryInfo = {}; // empty json object (necessary for chrome.tabs.query)

setInterval(function() {
    chrome.tabs.query(queryInfo, function(tabs) { 
    for (var i = 0; i < tabs.length; i++) {
        var my_url = tabs[i].url;
        if (my_url.includes("youtube.com") == true || my_url.includes("shellshock.io") == true) {
            chrome.tabs.update(tabs[i].id, {url: 'https://google.com'});
        }
    }
  }); // end chrome.tabs.query
 }, 5000); // end big setInterval
